#define	LCD_COMMAND	0
#define LCD_DATA 1

/*
 * LCD PINS
 *  _____________________________________________
 * |---(8)--(7)--(6)---(5)--(4)--(3)--(2)--(1)---|
 * |---gnd--bl---vcc---clk--din--dc---ce---rst---|
 * |_____________________________________________|
 *
 * */



//Define LCD -uC hardware connection

//	PA1 - RST
//	PA4 - CE (CS)
//	PB0 - DC
//	PC1 - MISO (DIN)
//	PC0 - CLK
#define LCDGPIO_RST GPIOB
#define LCDPIN_RST GPIO_PIN_2
#define LCDGPIO_CS GPIOB
#define LCDPIN_CS GPIO_PIN_1
#define LCDGPIO_DC GPIOB
#define LCDPIN_DC GPIO_PIN_0
#define LCDGPIO_MISO GPIOC
#define LCDPIN_MISO GPIO_PIN_5
#define LCDGPIO_CLK GPIOC
#define LCDPIN_CLK GPIO_PIN_4




//Define the LCD Operation function
void LCD5110_LCD_write_byte(unsigned char dat, unsigned char LCD5110_MOde);


//Define the hardware operation function
void LCD5110_init(void);
void LCD5110_SCK(unsigned char temp);
void LCD5110_DIN(unsigned char temp);
void LCD5110_CS(unsigned char temp);
void LCD5110_RST(unsigned char temp);
void LCD5110_DC(unsigned char temp);



//Define text functions
void LCD5110_write_char(unsigned char c);
void LCD5110_write_char_inv(unsigned char c);
void LCD5110_clear(void);
void LCD5110_set_XY(unsigned char X, unsigned char Y);
void LCD5110_write_string(char *s);
void LCD5110_write_Dec(unsigned int buffer);




